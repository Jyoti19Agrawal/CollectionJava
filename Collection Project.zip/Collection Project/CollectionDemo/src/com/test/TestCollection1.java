package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestCollection1 {
 public static void main(String[] args) {
	 List list=new ArrayList();
	 //Set list=new TreeSet(new EmployeeComparator());
	 //Set list=new TreeSet();
	 
	 //Set<Employee> list=new TreeSet<Employee>(new EmployeeComparator());
	 Employee e1=new Employee(1,"Jyoti",9000);
	 Employee e2=new Employee(6,"zehal",8000);
	 Employee e3=new Employee(3,"Payal",5000);
	 list.add(e1);
	 list.add(e2);
	 list.add(e3);
	Collections.sort(list);//it cannot sort because employee type is not comparable.classcast exception
	 
	 
	 //Collections.sort(list,new EmployeeComparator());
	 /*Iterator iterator= list.iterator();
		while(iterator.hasNext())
		{
		Object obj=iterator.next();
		System.out.println(obj);
		}*/
	 
	 //list.forEach(p->System.out.println(p));
	 
	 
	 /*for(Object obj : list)
		{
			//String str= (String)obj; 
			System.out.println(obj);
			 
		}*/
	 
	 // to get employee name
	 for(Object obj : list)
		{
			Employee str= (Employee)obj; 
			System.out.println(str);
			 
		}
}
}

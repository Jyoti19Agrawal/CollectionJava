package com.test;

public class Data<T> {//to declare class as a generic class 
	private T data;

	public T getData() { //make the return type of member as object so that it can be use as integer or string or any other form .
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	 

}

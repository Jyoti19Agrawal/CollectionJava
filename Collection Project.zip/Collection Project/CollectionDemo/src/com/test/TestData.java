package com.test;

public class TestData {
	public static void main(String[] args) {
		Data<Integer> ob=new Data<Integer>();
		Data<String> ob1=new Data<String>();
		Data <Employee> ob2=new Data<Employee>();
		ob.setData(100);
		ob1.setData("John");
		ob2.setData(new Employee());
		
		Employee emp= ob2.getData();
		System.out.println(emp);
		int i=ob.getData();
		System.out.println(i);
		
		String str=ob1.getData();
		System.out.println(str);
	}
}

package com.test;

import java.util.Collection;
import java.util.HashMap;

public class TestMap {
	public static void main(String[] args) {
		
	
	HashMap<Integer,Employee> map;
	map=new HashMap<Integer,Employee>();
	 Employee e1=new Employee(104,"Jyoti",9000);
	 Employee e2=new Employee(102,"zehal",8000);
	 Employee e3=new Employee(103,"Payal",5000);
	 Employee e4=new Employee(103,"Payal",5000);
	 
	 map.put(102,e2);
	 map.put(104,e1);
	 map.put(103,e3);
	 map.put(103,e3);
	 
	 if(map.containsKey(104))
	 {
		 Employee emp=map.get(104);
		 System.out.println(emp);
	 }
	 else
	 {
		 System.out.println("Employee Not found");
	 }
	 
	 Collection<Employee> colletcion= map.values();
	 colletcion.forEach(p->System.out.println(p));
	}	 
}

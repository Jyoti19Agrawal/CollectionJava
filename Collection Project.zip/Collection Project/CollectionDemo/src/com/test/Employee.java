package com.test;
public class Employee {
//public class Employee implements Comparable{
	private int empId;
	private String empName;
	private int empSal;
	public Employee(int empId, String empName, int empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	public Employee() {
		super();
		 
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}
	/*@Override
	public int compareTo(Object obj) {
		 
		 Employee emp=(Employee) obj;
		int n= this.empId - emp.empId;//"this" we will use my code is modified
		return n;*/
		 
		 /*int n=this.empName.compareTo(emp.empName);//if you want to get output using name
		 return n;*/
		 
		/* we can use this method also
		 * Employee emp=(Employee) obj
		 * if( this.empId = emp.empId)
		 {
			
		 return 0;
		 }
		 else if(this.empId>emp.empId )
		 {
		  
		 return 1;
		 }
		 else
		 {
		  
		 return -1;
		 }
			*/
		}

	
	
	
	
	





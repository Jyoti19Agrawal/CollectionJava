package com.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;

public class TestCollection {
	public static void main(String[] args) {
		//ArrayList list=new ArrayList();
		//List list=new ArrayList();//it will work
		//Collection list=new ArrayList();//it will show error for every index based method
		//try to avoid printing using get
		
		
		//Collection list=new LinkedList();
		
		//Collection list=new Vector();
		
		//Collection list=new HashSet();//non index based, unordered, no duplicate
		
		//Collection list=new LinkedHashSet();// no duplicate, ordered list
		
		//Collection list=new TreeSet();// for sorted list, no duplicate
		
		List list=new ArrayList();
		
		list.add(10);
		list.add(100);
		list.add(30);
		list.add(8);
		
		Collections.sort(list);
		//Collections.reverse(list);
		//Collections.shuffle(list);
		
		
		/*list.add("orange");
		list.add("apple");
		list.add("banana");
		list.add("chikoo");*/
		
		//list.add("banana");// no duplicates are allowed it will return false
		//System.out.println(list.add("apple"));//to check it is added or not
		//System.out.println(list.add("Chikoo"));//it will return true
		//list.add(3,"Grape");//this will not work if we List to collection
		/*list.clear();
		int n=list.size();
		
		System.out.println(" size= "+n);
		String obj=(String)list.get(1);//string is object but object is not string so typecast it
		System.out.println(obj);
		Object obj1=list.get(3);
		System.out.println(obj);*/
		
		//this is the one way
		/*for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}
		System.out.println(".....................");
		
		//another way is for-each loop*/
		
		/*for(Object obj : list)
		{
			String str= (String)obj;//without this also it will work but it is going to cal toString method
			System.out.println(str);
			System.out.println("Length: "+str.length());
			}*/
			 
		
		
		System.out.println("To copy all element from one object to another object");
		//through iterator
		Iterator iterator= list.iterator();
		
		while(iterator.hasNext())
		{
		Object obj=iterator.next();
		System.out.println(obj);
		}
		
		System.out.println("Another method is enumeration");
		
		System.out.println("To avoid much coding, another way is.....");
		
		list.forEach(p->System.out.println(p));//here we are telling what to iterate and in above method we are telling how to iterate.
	}
}

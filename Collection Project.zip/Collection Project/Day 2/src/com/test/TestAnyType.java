package com.test;

import java.util.ArrayList;

public class TestAnyType {
	public static void main(String[] args) {
		 ArrayList<? extends Number> list= new ArrayList();
		 
		  
		 
	}
	


}

package com.test;

 
 
import java.util.ArrayList;
import java.util.List;

class MyException extends Exception

{
	public MyException(String msg) {
		super(msg);
	}
}

public class TestGeneric {
	// to retrieve all elements
	public static List<String> getAllElements(List<String> list)
	{
		ArrayList<String> mylist=new ArrayList<String>();
		for(String str : list)
		{
			mylist.add(str);
		}
		return mylist;
	}

	public static void printLastElement(List<String> list) throws MyException {
		if (list != null && list.size() > 0) {
			int n = list.size() - 1;
			String str = list.get(n);
			System.out.println(str);
		} else {
			throw new MyException("List is empty or null");
		}
	}

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("one");
		list.add("two");
		list.add("three");
		
		//ArrayList<String> list=null;
		
		try {
			printLastElement(list);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e);
		}
		
		
		List<String> nlist=getAllElements(list);
		for(String str : nlist)
		{
			System.out.println(str);
		}
		/*list.add("one");
		list.add("two");
		list.add("three");
		String str=list.get(list.size()-1);// to print the last element
		System.out.println(str);*/
		
		
		/*for(String s : list)
		{
			System.out.println(s);
		}*/
			 
	}
}

package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnection {

	public static void main(String[] args) {
		
		//it will fail because class and driver are not defined which is inside odbc.jar file
		 try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Registered Successfully");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user="system";
			String pass="orcl11g";
			Connection con= DriverManager.getConnection(url,user,pass);
			System.out.println("Connected successfully");
			Statement stmt= con.createStatement();
			String myquery="select empid,empname,empsalary from emp_tbl";
			ResultSet result = stmt.executeQuery(myquery);
			
			while(result.next())
			{
				int id= result.getInt("empid");
				String name= result.getString("empname");
				int sal= result.getInt(3);//we can also access it from column number also.
				System.out.println(id+ " "+ name + " "+sal);
			}
			con.close();
		} catch (ClassNotFoundException e) {
			 System.out.println(" Driver not found ");
			 
		} catch (SQLException e) {
			 System.out.println(e);
		}
		

	}

}

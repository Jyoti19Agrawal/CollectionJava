package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestInsert {

	public static void main(String[] args) {
		 
		 try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				System.out.println("Driver Registered Successfully");
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="system";
				String pass="orcl11g";
				Connection con= DriverManager.getConnection(url,user,pass);
				System.out.println("Connected successfully");
				con.setAutoCommit(false);
				/*create statement
				Statement stmt= con.createStatement();
				
				
				insert values
				String command= " insert into emp_tbl values (1003,'Nehal',9000)";
				
				int n= stmt.executeUpdate(command);
				System.out.println("Number of Records inserted = "+n);*/
				
				//parametriezed statement
				//String command= " insert into emp_tbl(empid,empname,empsalary) values (?,?,?)";
				
				String command= " insert into emp_tbl(empid,empname,empsalary) values (empid_sequence.nextval,?,?)";
				//for best practice always specify all the field along with table name
				PreparedStatement pstmt=con.prepareStatement(command);
				
				//pstmt.setInt(1, 1005);
				pstmt.setString(1, "Sonu");
				pstmt.setInt(2, 80000);
				int n=pstmt.executeUpdate();
				System.out.println("Insert success n ="+n);
				
				//to commit the queries
				System.out.println("1.commit 2.Rollback ");
				Scanner sc=new Scanner(System.in);
				int option = sc.nextInt();
				if(option==1)
					con.commit();
				else
				{
					con.rollback();
				}
				con.close();
				
			} catch (ClassNotFoundException e) {
				 System.out.println(" Driver not found ");
				 
			} catch (SQLException e) {
				e.printStackTrace();
			}
			


	}

}

package com.test;

public class TestProperty {

	public static void main(String[] args) {
		 

	}

}

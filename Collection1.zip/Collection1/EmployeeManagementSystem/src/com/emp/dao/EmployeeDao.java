package com.emp.dao;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeDao {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean deleteEmployeeById(int id);
	//public List<EmployeeBean> viewllEmployee();
 // assignment
}

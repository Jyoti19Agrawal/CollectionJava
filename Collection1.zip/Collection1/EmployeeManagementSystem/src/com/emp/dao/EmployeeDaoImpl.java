package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.Generated;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao {
	/*public int generateEmployeeId()
	{
		int id=0;
		Connection con= DBConnection.getConnection();
		String myquery = "select empid_sequence.nextval from dual";
		try {
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(myquery);
			rst.next();// to move cursor
			id=rst.getInt(1);// here 1 is the column 1 means id column
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con = DBConnection.getConnection();
		int id=0;
		String cmd = "insert into emp_tbl(empid,empname,empsalary) values (?,?,?)";
		try {
			id=generateEmployeeId();
			PreparedStatement pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmpname());
			pstmt.setInt(3, bean.getEmpsalary());
			int n = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new EmployeeException("Unable to insert");

		}
		return id;
	}*/
}
